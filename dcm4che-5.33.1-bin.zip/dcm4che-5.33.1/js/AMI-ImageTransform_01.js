DCM4CHE.elementName.addDictionary({
"privateCreator":"AMI ImageTransform_01",
"3107xx10":"Transformation Matrix",
"3107xx20":"Center Offset",
"3107xx30":"Magnification",
"3107xx40":"Magnification Type",
"3107xx50":"Displayed Area",
"3107xx60":"Calibration Factor"
});
