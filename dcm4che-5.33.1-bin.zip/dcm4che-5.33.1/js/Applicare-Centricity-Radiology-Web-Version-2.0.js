DCM4CHE.elementName.addDictionary({
"privateCreator":"Applicare/Centricity Radiology Web/Version 2.0",
"4111xx01":"Secondary Spine Label",
"4111xx02":"Additional tags for Presentation State"
});
