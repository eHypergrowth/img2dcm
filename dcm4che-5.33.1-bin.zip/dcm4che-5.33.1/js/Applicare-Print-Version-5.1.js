DCM4CHE.elementName.addDictionary({
"privateCreator":"Applicare/Print/Version 5.1",
"4101xx01":"Mask State",
"4101xx02":"Annotations",
"4101xx03":"Font",
"4101xx04":"Font Size",
"4101xx05":"Font Relative Size",
"4101xx06":"Overlay",
"4101xx07":"Pixel Rep",
"4101xx08":"Annotation Level",
"4101xx09":"Show Caliper"
});
