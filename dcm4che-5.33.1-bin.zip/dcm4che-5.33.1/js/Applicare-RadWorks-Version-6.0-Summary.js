DCM4CHE.elementName.addDictionary({
"privateCreator":"Applicare/RadWorks/Version 6.0/Summary",
"3109xx01":"Status",
"3109xx11":"Receive Origin Site Name",
"3109xx12":"Receive Origin Description",
"3109xx15":"Receive Date",
"3109xx16":"Receive Time"
});
