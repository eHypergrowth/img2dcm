DCM4CHE.elementName.addDictionary({
"privateCreator":"GEMS_0039",
"0039xx95":"SR Application Name"
});
