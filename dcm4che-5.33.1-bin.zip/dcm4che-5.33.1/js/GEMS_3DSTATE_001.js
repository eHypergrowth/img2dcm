DCM4CHE.elementName.addDictionary({
"privateCreator":"GEMS_3DSTATE_001",
"0047xxE9":"?",
"0047xxEA":"?",
"0047xxEB":"?",
"0047xxEC":"?",
"0047xxED":"?"
});
