DCM4CHE.elementName.addDictionary({
"privateCreator":"GEMS_ADWSoft_DPO",
"0039xx80":"Private Entity Number",
"0039xx85":"Private Entity Date",
"0039xx90":"Private Entity Time",
"0039xx95":"Private Entity Launch Command",
"0039xxAA":"Private Entity Type"
});
