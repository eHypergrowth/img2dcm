DCM4CHE.elementName.addDictionary({
"privateCreator":"GEMS_CTHD_01",
"0033xx02":"?"
});
