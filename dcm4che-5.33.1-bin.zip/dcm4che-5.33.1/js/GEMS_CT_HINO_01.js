DCM4CHE.elementName.addDictionary({
"privateCreator":"GEMS_CT_HINO_01",
"004Bxx01":"Beam Thickess",
"004Bxx02":"R Time",
"004Bxx03":"HBC Number"
});
