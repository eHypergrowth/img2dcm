DCM4CHE.elementName.addDictionary({
"privateCreator":"GEMS_CT_VES_01",
"0051xx01":"CTVESequence"
});
