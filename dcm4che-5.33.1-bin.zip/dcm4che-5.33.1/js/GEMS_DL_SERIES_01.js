DCM4CHE.elementName.addDictionary({
"privateCreator":"GEMS_DL_SERIES_01",
"0015xx85":"Series File Name",
"0015xx87":"Number of Images",
"0015xx8C":"Sent Flag",
"0015xx8D":"Item Locked",
"0019xx4C":"Internal Label",
"0019xx4D":"Browser Hide"
});
