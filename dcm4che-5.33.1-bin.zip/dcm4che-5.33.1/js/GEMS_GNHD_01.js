DCM4CHE.elementName.addDictionary({
"privateCreator":"GEMS_GNHD_01",
"0033xx01":"?",
"0033xx02":"?"
});
