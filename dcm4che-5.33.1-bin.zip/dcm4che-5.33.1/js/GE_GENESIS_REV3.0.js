DCM4CHE.elementName.addDictionary({
"privateCreator":"GE_GENESIS_REV3.0",
"0019xx39":"Axial Type",
"0019xx8F":"Swap Phase Frequency",
"0019xx9C":"Pulse Sequence Name",
"0019xx9F":"Coil Type",
"0019xxA4":"SAT Fat Water Bone",
"0019xxC0":"Bitmap Of SAT Selections",
"0019xxC1":"Surface Coil Intensity Correction Flag",
"0019xxCB":"Phase Contrast Flow Axis",
"0019xxCC":"Phase Contrast Velocity Encoding",
"0019xxD5":"Fractional Echo",
"0019xxD8":"Variable Echo Flag",
"0019xxD9":"Concatenated Sat",
"0019xxF2":"Number Of Phases",
"0043xx1E":"Delta Start Time",
"0043xx27":"Scan Pitch Ratio"
});
