DCM4CHE.elementName.addDictionary({
"privateCreator":"ISI",
"0009xx01":"SIENET General Purpose IMGEF"
});
