DCM4CHE.elementName.addDictionary({
"privateCreator":"PHILIPS MR",
"0009xx10":"SPI Release",
"0009xx12":"?"
});
