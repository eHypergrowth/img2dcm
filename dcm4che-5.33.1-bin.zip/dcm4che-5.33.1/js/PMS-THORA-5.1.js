DCM4CHE.elementName.addDictionary({
"privateCreator":"PMS-THORA-5.1",
"0089xx20":"?"
});
