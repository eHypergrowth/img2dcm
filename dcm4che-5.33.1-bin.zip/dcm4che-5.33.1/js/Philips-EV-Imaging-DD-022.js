DCM4CHE.elementName.addDictionary({
"privateCreator":"Philips EV Imaging DD 022",
"2007xx00":"?"
});
