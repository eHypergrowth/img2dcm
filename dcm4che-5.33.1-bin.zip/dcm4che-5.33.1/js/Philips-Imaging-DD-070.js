DCM4CHE.elementName.addDictionary({
"privateCreator":"Philips Imaging DD 070",
"4001xx10":"?",
"4001xx11":"?",
"4001xx12":"?",
"4001xx13":"?",
"4001xx16":"?",
"4001xx17":"?",
"4001xx18":"?",
"4001xx1C":"",
"4001xx1D":"?"
});
