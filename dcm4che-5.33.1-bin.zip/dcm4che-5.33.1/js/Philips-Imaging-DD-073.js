DCM4CHE.elementName.addDictionary({
"privateCreator":"Philips Imaging DD 073",
"4007xx48":"?",
"4007xx4B":"?",
"4007xx4C":"?",
"4007xx4D":"?",
"4007xx4E":"?",
"4007xx4F":"?"
});
