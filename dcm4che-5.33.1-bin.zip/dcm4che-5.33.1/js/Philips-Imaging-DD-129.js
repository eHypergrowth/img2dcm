DCM4CHE.elementName.addDictionary({
"privateCreator":"Philips Imaging DD 129",
"2001xx00":"Presentation State Sequence"
});
