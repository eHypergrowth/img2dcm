DCM4CHE.elementName.addDictionary({
"privateCreator":"Philips US Imaging DD 023",
"200Dxx37":"?",
"200Dxx38":"?",
"200Dxx45":"?"
});
