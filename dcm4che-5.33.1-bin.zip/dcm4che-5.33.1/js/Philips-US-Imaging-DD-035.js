DCM4CHE.elementName.addDictionary({
"privateCreator":"Philips US Imaging DD 035",
"200Dxx01":"?",
"200Dxx03":"?",
"200Dxx04":"?",
"200Dxx07":"?",
"200Dxx08":"?",
"200Dxx09":"?",
"200Dxx0A":"?",
"200Dxx0C":"?",
"200Dxx0D":"?"
});
