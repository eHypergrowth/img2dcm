DCM4CHE.elementName.addDictionary({
"privateCreator":"SHS MagicView 300",
"0029xx02":"?",
"0029xx03":"?"
});
