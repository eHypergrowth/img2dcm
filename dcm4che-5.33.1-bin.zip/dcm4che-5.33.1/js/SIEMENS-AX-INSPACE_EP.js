DCM4CHE.elementName.addDictionary({
"privateCreator":"SIEMENS AX INSPACE_EP",
"0009xx50":"?",
"0009xx51":"?"
});
