DCM4CHE.elementName.addDictionary({
"privateCreator":"SIEMENS CSA ENVELOPE",
"0029xx10":"syngo Report Data",
"0029xx11":"syngo Report Presentation"
});
