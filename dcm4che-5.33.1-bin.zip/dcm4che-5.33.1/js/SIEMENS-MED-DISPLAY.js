DCM4CHE.elementName.addDictionary({
"privateCreator":"SIEMENS MED DISPLAY",
"0029xx04":"Photometric Interpretation",
"0029xx10":"Rows of Submatrix",
"0029xx11":"Columns of Submatrix",
"0029xx20":"?",
"0029xx21":"?",
"0029xx50":"Origin of Submatrix",
"0029xx80":"?",
"0029xx99":"Shutter Type",
"0029xxA0":"Rows of Rectangular Shutter",
"0029xxA1":"Columns of Rectangular Shutter",
"0029xxA2":"Origin of Rectangular Shutter",
"0029xxB0":"Radius of Circular Shutter",
"0029xxB2":"Origin of Circular Shutter",
"0029xxC1":"Contour of Irregular Shutter"
});
