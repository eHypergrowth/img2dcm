DCM4CHE.elementName.addDictionary({
"privateCreator":"SIEMENS MED MG",
"0029xx10":"List of Group Numbers",
"0029xx15":"List of Shadow Owner Codes",
"0029xx20":"List of Element Numbers",
"0029xx30":"List of Total Display Length",
"0029xx40":"List of Display Prefix",
"0029xx50":"List of Display Postfix",
"0029xx60":"List of Text Position",
"0029xx70":"List of Text Concatenation"
});
