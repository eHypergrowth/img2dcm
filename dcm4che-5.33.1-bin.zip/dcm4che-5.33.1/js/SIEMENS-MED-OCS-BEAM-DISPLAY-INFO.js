DCM4CHE.elementName.addDictionary({
"privateCreator":"SIEMENS MED OCS BEAM DISPLAY INFO",
"0039xx76":"Beam Display Properties"
});
