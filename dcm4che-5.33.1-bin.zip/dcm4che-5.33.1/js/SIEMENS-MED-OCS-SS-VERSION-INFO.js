DCM4CHE.elementName.addDictionary({
"privateCreator":"SIEMENS MED OCS SS VERSION INFO",
"0039xx76":"Structure Set Predecessor"
});
