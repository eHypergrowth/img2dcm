DCM4CHE.elementName.addDictionary({
"privateCreator":"SIEMENS MED PT",
"0071xx21":"Registration Matrix UID",
"0071xx22":"Decay Correction DateTime",
"0071xx23":"Volume Index",
"0071xx24":"Time Slice Duration"
});
