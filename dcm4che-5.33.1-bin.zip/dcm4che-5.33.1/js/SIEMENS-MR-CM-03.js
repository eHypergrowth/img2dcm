DCM4CHE.elementName.addDictionary({
"privateCreator":"SIEMENS MR CM 03",
"0021xx01":"?",
"0021xx02":"?"
});
