DCM4CHE.elementName.addDictionary({
"privateCreator":"SIEMENS MR DATAMAPPING ATTRIBUTES",
"0011xx01":"Reprocessing Info",
"0011xx02":"Data Role Type",
"0011xx03":"Data Role Name",
"0011xx04":"Rescan Name",
"0011xx05":"?",
"0011xx06":"Cardiac Type Name",
"0011xx07":"Cardiac Type Name L2",
"0011xx08":"Misc Indicator",
"0011xx09":"?",
"0011xx0A":"?",
"0011xx0B":"?",
"0011xx0C":"Split Bagging Name",
"0011xx0D":"Split Sub Bagging Name",
"0011xx0E":"Stage Sub Bagging Name",
"0011xx0F":"Is Internal Data Role"
});
