DCM4CHE.elementName.addDictionary({
"privateCreator":"SIEMENS MR MRS 05",
"0021xx01":"Transmitter Reference Amplitude",
"0021xx02":"Hamming Filter Width",
"0021xx03":"CSI Gridshift Vector",
"0021xx04":"Mixing Time",
"0021xx40":"Series Protocol Instance",
"0021xx41":"Spectro Result Type",
"0021xx42":"Spectro Result Extend Type",
"0021xx43":"Post Proc Protocol",
"0021xx44":"Rescan Level",
"0021xx45":"Spectro Algo Result",
"0021xx46":"Spectro Display Params",
"0021xx47":"Voxel Number",
"0021xx48":"APR Sequence",
"0021xx49":"Sync Data",
"0021xx4A":"Post Proc Detailed Protocol",
"0021xx4B":"Spectro Result Extend Type Detailed"
});
