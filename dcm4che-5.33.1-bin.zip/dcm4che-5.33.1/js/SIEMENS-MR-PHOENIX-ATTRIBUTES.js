DCM4CHE.elementName.addDictionary({
"privateCreator":"SIEMENS MR PHOENIX ATTRIBUTES",
"0021xx01":"Mds Mode Mask",
"0021xx02":"Dixon",
"0021xx03":"Sequence File Name",
"0021xxF1":"Count of Pseudo Attributes"
});
