DCM4CHE.elementName.addDictionary({
"privateCreator":"SIEMENS SYNGO INSTANCE MANIFEST",
"0009xx00":"Temporary Original Header Sequence",
"0009xx10":"syngo Index Source AE Title"
});
