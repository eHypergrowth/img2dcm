DCM4CHE.elementName.addDictionary({
"privateCreator":"SIEMENS SYNGO TIME POINT SERVICE",
"0029xx01":"Time Point I",
"0029xx02":"Time Point Information",
"0029xx50":"Studies in Time Point Sequence"
});
