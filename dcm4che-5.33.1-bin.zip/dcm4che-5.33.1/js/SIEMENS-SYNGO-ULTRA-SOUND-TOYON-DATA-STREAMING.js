DCM4CHE.elementName.addDictionary({
"privateCreator":"SIEMENS SYNGO ULTRA-SOUND TOYON DATA STREAMING",
"7FD1xx01":"Padding",
"7FD1xx09":"Volume Version ID",
"7FD1xx10":"Volume Payload",
"7FD1xx11":"After Payload"
});
