DCM4CHE.elementName.addDictionary({
"privateCreator":"SPI-P-Private-DCI Release 1",
"0019xx10":"?",
"0019xx11":"?",
"0019xx12":"?",
"0019xx13":"?",
"0019xx14":"?",
"0019xx15":"?",
"0019xx16":"?",
"0019xx17":"?"
});
