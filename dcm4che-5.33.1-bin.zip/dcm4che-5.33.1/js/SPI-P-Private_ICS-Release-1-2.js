DCM4CHE.elementName.addDictionary({
"privateCreator":"SPI-P-Private_ICS Release 1;2",
"0029xx00":"?",
"0029xx01":"?",
"0029xx02":"?",
"0029xx03":"?",
"0029xx04":"?",
"0029xx05":"?",
"0029xx30":"?",
"0029xxA0":"?",
"0029xxA1":"?",
"0029xxA2":"?",
"0029xxA3":"?",
"0029xxA5":"?",
"0029xxA6":"?",
"0029xxD9":"?"
});
