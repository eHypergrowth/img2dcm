DCM4CHE.elementName.addDictionary({
"privateCreator":"SPI-P Release 2;1",
"0011xx18":"?",
"0023xx0D":"?",
"0023xx0E":"?"
});
