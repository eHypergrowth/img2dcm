DCM4CHE.elementName.addDictionary({
"privateCreator":"SPI Release 1",
"0009xx08":"?",
"0009xx10":"?"
});
