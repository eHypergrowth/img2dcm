DCM4CHE.elementName.addDictionary({
"privateCreator":"SPI",
"0029xx60":"Compression Algorithm"
});
