DCM4CHE.elementName.addDictionary({
"privateCreator":"http://www.gemedicalsystems.com/it_solutions/rad_pacs/",
"3115xx01":"Reference to pacs study",
"3115xx02":"Reference to pacs image",
"3115xx03":"Pacs examnotes flag"
});
